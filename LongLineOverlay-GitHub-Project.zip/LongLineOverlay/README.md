# Long Line Overlay (Android)

A small Android floating overlay that draws a manually positioned cue-to-target line. It does not inject into 8 Ball Pool, inspect game memory, or automatically identify balls.

## Build APK using GitHub Actions

1. Create a GitHub repository named `long-line-overlay`.
2. Upload all files and folders from this project to the repository root.
3. Push to the `main` branch.
4. Open **Actions** → **Build Android APK**.
5. Open the completed workflow run and download the `long-line-overlay-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

## Install and use

1. Install the APK on Android 8.0 or newer.
2. Open **Long Line Overlay**.
3. Tap **Enable and show overlay**.
4. Allow **Display over other apps** in Android settings.
5. Return to the app. Drag the blue CUE point and green TARGET point to position the guide.
6. Tap the red × at the upper-right of the overlay to hide it. If needed, reopen the app and use **Hide overlay**.

## Notes

- The overlay is manually positioned; it is not an automatic ESP detector.
- Android may restrict overlays over certain apps or secure screens.
- This workflow produces an unsigned debug APK suitable for local testing, not a Play Store release.
