package id.frezen.longlineoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestOverlay = 7301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(18, 23, 31))
        }

        val title = TextView(this).apply {
            text = "LONG LINE OVERLAY"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Floating manual aim guide. Drag the blue point and green point to align the line with the table."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        val start = Button(this).apply {
            text = "Enable and show overlay"
            setOnClickListener { enableOverlay() }
        }
        val stop = Button(this).apply {
            text = "Hide overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        val note = TextView(this).apply {
            text = "This version draws a manually positioned guide; it does not automatically detect balls or read game memory."
            textSize = 13f
            setTextColor(Color.rgb(255, 210, 120))
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }

        root.addView(title)
        root.addView(description)
        root.addView(start)
        root.addView(stop)
        root.addView(note)
        setContentView(root)
    }

    private fun enableOverlay() {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java))
        } else {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, requestOverlay)
        }
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java))
        }
    }
}
