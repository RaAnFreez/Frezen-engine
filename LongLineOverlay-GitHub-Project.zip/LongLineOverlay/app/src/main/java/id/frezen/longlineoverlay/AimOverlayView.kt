package id.frezen.longlineoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class AimOverlayView(context: Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.CYAN
        strokeWidth = 5f
        style = Paint.Style.STROKE
    }
    private val cuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(70, 160, 255)
        style = Paint.Style.FILL
    }
    private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(70, 230, 130)
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 32f
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }
    private val path = Path()
    private var cueX = 0f
    private var cueY = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var activePoint = 0
    private val radius = 22f
    private var initialized = false

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!initialized) {
            cueX = width * 0.25f
            cueY = height * 0.62f
            targetX = width * 0.72f
            targetY = height * 0.38f
            initialized = true
        }

        // A faint backdrop makes the draggable handles visible without blocking the whole screen.
        val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x66000000
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(24f, 48f, 440f, 142f, 18f, 18f, hintPaint)
        canvas.drawText("LONG LINE • drag points", 42f, 88f, labelPaint)
        canvas.drawText("Tap the X to hide", 42f, 126f, labelPaint)

        linePaint.color = Color.CYAN
        canvas.drawLine(cueX, cueY, targetX, targetY, linePaint)

        // Extend the aim guide beyond the target to create a long-line sight.
        val dx = targetX - cueX
        val dy = targetY - cueY
        val length = hypot(dx, dy).coerceAtLeast(1f)
        val endX = targetX + (dx / length) * (width * 0.45f)
        val endY = targetY + (dy / length) * (width * 0.45f)
        linePaint.color = 0xCC00FFFF.toInt()
        linePaint.strokeWidth = 3f
        canvas.drawLine(targetX, targetY, endX, endY, linePaint)
        linePaint.strokeWidth = 5f

        canvas.drawCircle(cueX, cueY, radius, cuePaint)
        canvas.drawCircle(targetX, targetY, radius, targetPaint)
        canvas.drawText("CUE", cueX + 28f, cueY - 20f, labelPaint)
        canvas.drawText("TARGET", targetX + 28f, targetY - 20f, labelPaint)

        val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.RED
            textSize = 42f
            isFakeBoldText = true
        }
        canvas.drawText("×", width - 58f, 92f, xPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (event.x > width - 100f && event.y < 130f) {
                    context.stopService(android.content.Intent(context, OverlayService::class.java))
                    return true
                }
                val cueDistance = hypot(event.x - cueX, event.y - cueY)
                val targetDistance = hypot(event.x - targetX, event.y - targetY)
                activePoint = if (cueDistance <= targetDistance) 1 else 2
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (activePoint == 1) {
                    cueX = event.x
                    cueY = event.y
                } else {
                    targetX = event.x
                    targetY = event.y
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activePoint = 0
                return true
            }
        }
        return true
    }
}
