plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.frezen.longlineoverlay"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.frezen.longlineoverlay"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
